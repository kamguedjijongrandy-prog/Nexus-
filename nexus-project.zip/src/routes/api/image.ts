import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";

type Body = { prompt?: string; style?: string };

async function generateImage(prompt: string, apiKey: string) {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-image",
      modalities: ["image", "text"],
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!res.ok) throw new Error(`Image gateway ${res.status}: ${await res.text()}`);
  const json = (await res.json()) as {
    choices?: Array<{ message?: { images?: Array<{ image_url?: { url?: string } }> } }>;
  };
  const url = json.choices?.[0]?.message?.images?.[0]?.image_url?.url;
  if (!url) throw new Error("No image returned");
  return url;
}

export const Route = createFileRoute("/api/image")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { prompt, style } = (await request.json()) as Body;
        if (!prompt || prompt.trim().length < 3) {
          return new Response("Prompt required", { status: 400 });
        }
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        const finalPrompt = style ? `${prompt.trim()}. Style: ${style}.` : prompt.trim();
        try {
          const imageUrl = await generateImage(finalPrompt, key);
          return Response.json({ imageUrl, prompt: finalPrompt });
        } catch (e) {
          return new Response(e instanceof Error ? e.message : "Failed", { status: 500 });
        }
      },
    },
  },
});