import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { convertToModelMessages, stepCountIs, streamText, tool, type UIMessage } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";

type ChatRequestBody = { messages?: unknown };

const SYSTEM_PROMPT = `You are Nexus, a multimodal AI assistant.

Capabilities:
- Answer any question — text or about an uploaded image/file — with clarity and warmth.
- When the user uploads an image, analyze it carefully (objects, style, mood, text, context) and reference what you see in your answer.
- Generate or replicate images by calling the \`generate_image\` tool.

IMPORTANT — Auto-illustrate every answer:
For EVERY user message, after writing your text answer, ALWAYS call the \`generate_image\` tool exactly once with a concise, vivid visual representation of the user's question or topic (a single illustrative scene, ~1 sentence prompt). This gives the user a visual companion to every reply.

Exceptions where you may skip the auto-illustration:
- The user explicitly asks NOT to generate an image.
- The user uploaded an image AND only asks a factual question about it (e.g. "what brand is this?") where an illustration would add nothing — in that case you may skip.

If the user asks to "replicate", "recreate", or "remix" an uploaded image, call \`generate_image\` with a detailed prompt that reconstructs the subject, composition, style, lighting and mood of the uploaded image.

When generating an image, write a vivid prompt (subject, setting, lighting, style, mood) — don't just echo the user's words. Reply in the user's language. Use markdown. Be concise.`;

async function generateImageViaGateway(prompt: string, apiKey: string) {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-image",
      modalities: ["image", "text"],
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Image gateway error ${res.status}: ${text}`);
  }

  const json = (await res.json()) as {
    choices?: Array<{
      message?: { images?: Array<{ image_url?: { url?: string } }> };
    }>;
  };
  const url = json.choices?.[0]?.message?.images?.[0]?.image_url?.url;
  if (!url) throw new Error("No image returned from gateway");
  return url;
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        const gateway = createLovableAiGatewayProvider(key);
        const model = gateway("google/gemini-3-flash-preview");

        const tools = {
          generate_image: tool({
            description:
              "Generate an image from a vivid text prompt. Use whenever the user asks for any visual content.",
            inputSchema: z.object({
              prompt: z
                .string()
                .min(3)
                .describe("A detailed visual prompt: subject, setting, style, lighting, mood."),
              alt: z.string().describe("Short alt text describing the image."),
            }),
            execute: async ({ prompt, alt }) => {
              try {
                const imageUrl = await generateImageViaGateway(prompt, key);
                return { imageUrl, alt, prompt };
              } catch (err) {
                return {
                  error: err instanceof Error ? err.message : "Image generation failed",
                };
              }
            },
          }),
        };

        const result = streamText({
          model,
          system: SYSTEM_PROMPT,
          tools,
          stopWhen: stepCountIs(50),
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});