import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";
import { generateText, Output } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";

const LyricsSchema = z.object({
  title: z.string(),
  lyrics: z.string().describe("Full song lyrics with [Verse], [Chorus] section tags. 12-24 lines."),
  voiceStyle: z.string().describe("Short instruction for how to read the lyrics emotionally."),
  musicStyle: z.string().describe("Detailed music production prompt: genre, instruments, tempo, mood."),
});

async function elevenlabs(path: string, body: unknown, apiKey: string): Promise<ArrayBuffer> {
  const res = await fetch(`https://api.elevenlabs.io/v1${path}`, {
    method: "POST",
    headers: { "xi-api-key": apiKey, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`ElevenLabs ${path} failed [${res.status}]: ${err.slice(0, 200)}`);
  }
  return res.arrayBuffer();
}

export const Route = createFileRoute("/api/music")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        try {
          const { prompt } = (await request.json()) as { prompt?: string };
          if (!prompt || typeof prompt !== "string") {
            return new Response("prompt required", { status: 400 });
          }

          const lovableKey = process.env.LOVABLE_API_KEY;
          const elevenKey = process.env.ELEVENLABS_API_KEY;
          if (!lovableKey) return new Response("LOVABLE_API_KEY missing", { status: 500 });
          if (!elevenKey) return new Response("ELEVENLABS_API_KEY missing", { status: 500 });

          const gateway = createLovableAiGatewayProvider(lovableKey);
          const model = gateway("google/gemini-3-flash-preview");

          // 1) Lyrics + styles
          const { output } = await generateText({
            model,
            output: Output.object({ schema: LyricsSchema }),
            prompt: `Write an original song based on this idea: "${prompt}". Return a catchy title, full lyrics with [Verse]/[Chorus] tags (12-24 lines), a short voice delivery style, and a detailed music production prompt (genre, tempo BPM, instruments, mood).`,
          });

          // 2) Voice + Song in parallel
          const cleanLyrics = output.lyrics.replace(/\[[^\]]+\]/g, "").trim();
          const [voiceBuf, songBuf] = await Promise.all([
            elevenlabs(
              `/text-to-speech/EXAVITQu4vr4xnSDxMaL?output_format=mp3_44100_128`,
              {
                text: cleanLyrics,
                model_id: "eleven_multilingual_v2",
                voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.6, use_speaker_boost: true },
              },
              elevenKey,
            ).catch((e) => {
              console.error("Voice gen failed:", e);
              return null;
            }),
            elevenlabs(
              `/music`,
              { prompt: `${output.musicStyle}. Theme: ${prompt}`, music_length_ms: 30000 },
              elevenKey,
            ).catch((e) => {
              console.error("Music gen failed:", e);
              return null;
            }),
          ]);

          return Response.json({
            title: output.title,
            lyrics: output.lyrics,
            voiceStyle: output.voiceStyle,
            musicStyle: output.musicStyle,
            voiceB64: voiceBuf ? Buffer.from(voiceBuf).toString("base64") : null,
            songB64: songBuf ? Buffer.from(songBuf).toString("base64") : null,
          });
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          console.error("music route error:", msg);
          return new Response(msg, { status: 500 });
        }
      },
    },
  },
});