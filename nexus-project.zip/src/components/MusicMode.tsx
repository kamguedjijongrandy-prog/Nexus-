import { useState } from "react";
import { Loader2, Music2, X, Sparkles, Mic, Disc3, FileDown, Copy, Check } from "lucide-react";
import { jsPDF } from "jspdf";

type MusicResult = {
  title: string;
  lyrics: string;
  voiceStyle: string;
  musicStyle: string;
  voiceB64: string | null;
  songB64: string | null;
};

export function MusicMode({ onClose }: { onClose: () => void }) {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<MusicResult | null>(null);
  const [copied, setCopied] = useState(false);

  const copyLyrics = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.lyrics);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setError("Couldn't access clipboard");
    }
  };

  const generate = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/music", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim() }),
      });
      if (!res.ok) throw new Error(await res.text());
      setResult((await res.json()) as MusicResult);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="glass relative w-full max-w-2xl rounded-3xl p-6 shadow-[var(--shadow-elevated)]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="mb-5 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-primary to-accent glow">
            <Music2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Music Mode</h2>
            <p className="text-xs text-muted-foreground">Idea → Lyrics → Voice → Song</p>
          </div>
        </div>

        <div className="space-y-3">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A love song about chasing success at 3am…"
            rows={3}
            className="w-full resize-none rounded-xl border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
          />
          <button
            type="button"
            onClick={generate}
            disabled={!prompt.trim() || loading}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-primary to-accent py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Composing… (this can take ~30s)
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Generate Song
              </>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive-foreground">
            {error}
          </div>
        )}

        {result && (
          <div className="mt-6 space-y-4">
            <div>
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Track</p>
              <h3 className="text-gradient text-2xl font-bold">{result.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{result.musicStyle}</p>
              <button
                type="button"
                onClick={() => exportLyricsPdf(result)}
                className="mt-3 inline-flex items-center gap-2 rounded-lg border border-border bg-secondary/60 px-3 py-1.5 text-xs font-medium text-foreground transition hover:border-primary/60 hover:text-primary"
              >
                <FileDown className="h-3.5 w-3.5" />
                Export lyrics as PDF
              </button>
              <button
                type="button"
                onClick={copyLyrics}
                className="ml-2 mt-3 inline-flex items-center gap-2 rounded-lg border border-border bg-secondary/60 px-3 py-1.5 text-xs font-medium text-foreground transition hover:border-primary/60 hover:text-primary"
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? "Copied!" : "Copy lyrics"}
              </button>
            </div>

            {result.songB64 && (
              <AudioCard
                icon={<Disc3 className="h-4 w-4" />}
                label="Finished Song"
                src={`data:audio/mpeg;base64,${result.songB64}`}
                fileName={`${slug(result.title)}-song.mp3`}
              />
            )}
            {result.voiceB64 && (
              <AudioCard
                icon={<Mic className="h-4 w-4" />}
                label="Vocal Read"
                src={`data:audio/mpeg;base64,${result.voiceB64}`}
                fileName={`${slug(result.title)}-vocal.mp3`}
              />
            )}

            <details className="rounded-xl border border-border bg-secondary/30 px-4 py-3 text-sm" open>
              <summary className="cursor-pointer text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Lyrics
              </summary>
              <pre className="mt-2 max-h-64 overflow-y-auto whitespace-pre-wrap font-sans text-sm leading-relaxed text-foreground">
                {result.lyrics}
              </pre>
            </details>
          </div>
        )}
      </div>
    </div>
  );
}

function AudioCard({
  icon,
  label,
  src,
  fileName,
}: {
  icon: React.ReactNode;
  label: string;
  src: string;
  fileName: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-secondary/40 p-4">
      <div className="mb-2 flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs font-medium text-foreground">
          <span className="text-primary">{icon}</span>
          {label}
        </span>
        <a
          href={src}
          download={fileName}
          className="text-[11px] text-primary hover:underline"
        >
          Download
        </a>
      </div>
      <audio controls src={src} className="w-full" />
    </div>
  );
}

function slug(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "track";
}

function exportLyricsPdf(result: MusicResult) {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 56;
  const contentW = pageW - margin * 2;
  let y = margin;

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(26);
  doc.setTextColor(20, 20, 30);
  const titleLines = doc.splitTextToSize(result.title, contentW);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 30 + 8;

  // Style subtitle
  doc.setFont("helvetica", "italic");
  doc.setFontSize(11);
  doc.setTextColor(110, 110, 130);
  const styleLines = doc.splitTextToSize(result.musicStyle, contentW);
  doc.text(styleLines, margin, y);
  y += styleLines.length * 14 + 14;

  // Accent divider
  doc.setDrawColor(120, 90, 220);
  doc.setLineWidth(1.5);
  doc.line(margin, y, margin + 64, y);
  y += 22;

  // Lyrics
  doc.setTextColor(30, 30, 40);
  const sections = result.lyrics.split(/\n/);
  for (const raw of sections) {
    const line = raw.trimEnd();
    if (y > pageH - margin) {
      doc.addPage();
      y = margin;
    }
    if (!line.trim()) {
      y += 10;
      continue;
    }
    const isTag = /^\[.+\]$/.test(line.trim());
    if (isTag) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(120, 90, 220);
      y += 6;
      doc.text(line.trim().toUpperCase(), margin, y);
      y += 16;
    } else {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(12);
      doc.setTextColor(30, 30, 40);
      const wrapped = doc.splitTextToSize(line, contentW);
      for (const w of wrapped) {
        if (y > pageH - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(w, margin, y);
        y += 16;
      }
    }
  }

  // Footer on each page
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(160, 160, 175);
    doc.text("Generated with Nexus Music Mode", margin, pageH - 28);
    doc.text(`Page ${i} / ${pageCount}`, pageW - margin, pageH - 28, { align: "right" });
  }

  doc.save(`${slug(result.title)}-lyrics.pdf`);
}