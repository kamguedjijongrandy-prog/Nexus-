import { X, ExternalLink, Sparkles } from "lucide-react";

type LinkItem = {
  name: string;
  url: string;
  tagline: string;
  accent: string;
};

const LINKS: LinkItem[] = [
  {
    name: "ChatGPT",
    url: "https://chat.openai.com",
    tagline: "OpenAI · conversational reasoning",
    accent: "from-emerald-400/30 to-emerald-600/10",
  },
  {
    name: "Gemini",
    url: "https://gemini.google.com",
    tagline: "Google · multimodal assistant",
    accent: "from-sky-400/30 to-indigo-600/10",
  },
  {
    name: "Claude",
    url: "https://claude.ai",
    tagline: "Anthropic · thoughtful long-form",
    accent: "from-orange-400/30 to-rose-600/10",
  },
];

export function AILinksModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-background/70 p-4 backdrop-blur-sm">
      <div className="glass relative w-full max-w-md overflow-hidden rounded-2xl p-5 shadow-[var(--shadow-elevated)]">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 rounded-md p-1 text-muted-foreground hover:text-foreground"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="mb-4 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-semibold">AI Links</h2>
        </div>
        <p className="mb-4 text-xs text-muted-foreground">
          Jump straight to another assistant in a new tab.
        </p>
        <ul className="space-y-2">
          {LINKS.map((l) => (
            <li key={l.name}>
              <a
                href={l.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center justify-between rounded-xl bg-gradient-to-br ${l.accent} px-4 py-3 transition hover:scale-[1.01]`}
              >
                <span className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">{l.name}</span>
                  <span className="text-[11px] text-muted-foreground">{l.tagline}</span>
                </span>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}