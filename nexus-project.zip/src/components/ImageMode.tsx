import { useState } from "react";
import { Loader2, Wand2, X, Sparkles, Download } from "lucide-react";

const STYLES = [
  { id: "realistic", label: "Realistic", hint: "photorealistic, 35mm, natural light" },
  { id: "cartoon", label: "Cartoon", hint: "flat 2D cartoon, bold outlines, vibrant" },
  { id: "oil", label: "Oil Painting", hint: "thick impasto oil painting, classical" },
  { id: "anime", label: "Anime", hint: "studio anime, cel shaded, expressive" },
  { id: "3d", label: "3D Render", hint: "octane 3D render, soft global illumination" },
  { id: "watercolor", label: "Watercolor", hint: "loose watercolor, paper texture, pastel" },
  { id: "cyberpunk", label: "Cyberpunk", hint: "neon cyberpunk, rainy night, volumetric" },
  { id: "minimal", label: "Minimal", hint: "minimalist vector, flat colors, lots of whitespace" },
];

export function ImageMode({ onClose }: { onClose: () => void }) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState(STYLES[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const generate = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setError(null);
    setImageUrl(null);
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim(), style: style.hint }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as { imageUrl: string };
      setImageUrl(data.imageUrl);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="glass relative w-full max-w-2xl rounded-3xl p-6 shadow-[var(--shadow-elevated)]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="mb-5 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-primary to-accent glow">
            <Wand2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Image Creation</h2>
            <p className="text-xs text-muted-foreground">Describe it, pick a style, download.</p>
          </div>
        </div>

        <div className="space-y-3">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A snow leopard meditating on a moss-covered shrine at dawn…"
            rows={3}
            className="w-full resize-none rounded-xl border border-border bg-secondary/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
          />

          <div>
            <p className="mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">Style</p>
            <div className="flex flex-wrap gap-1.5">
              {STYLES.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setStyle(s)}
                  className={`rounded-full border px-3 py-1 text-xs transition ${
                    style.id === s.id
                      ? "border-primary bg-primary/15 text-primary"
                      : "border-border bg-secondary/40 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={generate}
            disabled={!prompt.trim() || loading}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-primary to-accent py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Painting pixels…
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Generate Image
              </>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive-foreground">
            {error}
          </div>
        )}

        {imageUrl && (
          <figure className="mt-6 overflow-hidden rounded-2xl border border-border glow">
            <img src={imageUrl} alt={prompt} className="h-auto w-full" />
            <figcaption className="flex items-center justify-between gap-3 border-t border-border bg-secondary/40 px-4 py-2 text-xs text-muted-foreground">
              <span className="truncate">{style.label} · {prompt}</span>
              <a
                href={imageUrl}
                download={`nexus-${style.id}.png`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex shrink-0 items-center gap-1 rounded-md bg-secondary px-2 py-1 text-[11px] text-foreground hover:text-primary"
              >
                <Download className="h-3 w-3" />
                Download
              </a>
            </figcaption>
          </figure>
        )}
      </div>
    </div>
  );
}