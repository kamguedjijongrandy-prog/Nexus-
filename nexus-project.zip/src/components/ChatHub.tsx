import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  ArrowUp,
  Sparkles,
  ImageIcon,
  Loader2,
  Bot,
  User,
  Plus,
  Mic,
  MicOff,
  Camera,
  Image as ImageLucide,
  FileText,
  Wand2,
  Search,
  Code2,
  Link2,
  X,
  History,
  LogOut,
} from "lucide-react";
import { useNavigate } from "@tanstack/react-router";
import { ImageMode } from "./ImageMode";
import { AILinksModal } from "./AILinksModal";

const SUGGESTION_POOL: { icon: typeof Sparkles; label: string }[] = [
  { icon: Sparkles, label: "Explain quantum entanglement simply" },
  { icon: ImageIcon, label: "Generate a neon city at midnight" },
  { icon: Sparkles, label: "Write a haiku about black holes" },
  { icon: ImageIcon, label: "Create a portrait of a cosmic dragon" },
  { icon: Sparkles, label: "Summarize the plot of Dune in 3 lines" },
  { icon: ImageIcon, label: "Design a logo for a coffee startup" },
  { icon: Sparkles, label: "Teach me a Spanish phrase a day" },
  { icon: ImageIcon, label: "Render an aurora over Mt. Fuji at dawn" },
  { icon: Sparkles, label: "Draft a polite follow-up email" },
  { icon: ImageIcon, label: "Imagine a steampunk hot air balloon city" },
  { icon: Sparkles, label: "Compare REST vs GraphQL in plain English" },
  { icon: ImageIcon, label: "Sketch a minimalist bento dashboard UI" },
  { icon: Sparkles, label: "Give me a 5-minute morning stretch routine" },
  { icon: ImageIcon, label: "Paint a koi pond in Studio Ghibli style" },
];

function pickSuggestions(n = 4) {
  const arr = [...SUGGESTION_POOL];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.slice(0, n);
}

type HistoryItem = { id: string; title: string; prompt: string; at: number };

function makeTitle(text: string) {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= 48) return clean;
  return clean.slice(0, 45).trimEnd() + "…";
}

const transport = new DefaultChatTransport({ api: "/api/chat" });

type CreateTool = {
  id: string;
  label: string;
  description: string;
  icon: typeof Camera;
  accept?: string;
  capture?: "user" | "environment";
  prompt?: string;
  action?: "image" | "links";
};

const CREATE_TOOLS: CreateTool[] = [
  { id: "camera", label: "Camera", description: "Snap a photo for inspiration", icon: Camera, accept: "image/*", capture: "environment" },
  { id: "photos", label: "Photos", description: "Upload JPG, PNG or GIF", icon: ImageLucide, accept: "image/*" },
  { id: "files", label: "Files", description: "PDF, DOCX, TXT, audio or video", icon: FileText, accept: ".pdf,.doc,.docx,.txt,audio/*,video/*" },
  { id: "image", label: "Image Creation", description: "Style presets + download", icon: Wand2, action: "image" },
  { id: "research", label: "Deep Research", description: "Synthesize facts, trends and studies", icon: Search, prompt: "Do deep research on " },
  { id: "web", label: "Web Design", description: "Sketch a website or UI concept", icon: Code2, prompt: "Design a website for " },
  { id: "links", label: "AI Links", description: "Jump to ChatGPT, Gemini or Claude", icon: Link2, action: "links" },
];

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type SpeechRecognitionCtor = new () => any;

function getSpeechRecognition(): SpeechRecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function ChatHub() {
  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const { messages, sendMessage, status, error } = useChat({ transport });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const fileAcceptRef = useRef<string>("");
  const fileCaptureRef = useRef<"user" | "environment" | undefined>(undefined);
  const [attachments, setAttachments] = useState<File[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [imageOpen, setImageOpen] = useState(false);
  const [linksOpen, setLinksOpen] = useState(false);
  const [suggestions, setSuggestions] = useState(() => SUGGESTION_POOL.slice(0, 4));
  useEffect(() => {
    setSuggestions(pickSuggestions(4));
  }, []);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      return JSON.parse(localStorage.getItem("nexus.history") ?? "[]");
    } catch {
      return [];
    }
  });
  const [historyOpen, setHistoryOpen] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [status]);

  const isBusy = status === "submitted" || status === "streaming";

  const LogoutButton = () => (
    <button
      type="button"
      onClick={async () => {
        const { supabase } = await import("@/integrations/supabase/client");
        await supabase.auth.signOut();
        navigate({ to: "/login" });
      }}
      className="flex items-center gap-1.5 rounded-full glass px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
      aria-label="Sign out"
    >
      <LogOut className="h-3.5 w-3.5" />
      Sign out
    </button>
  );

  const submit = (text: string) => {
    const value = text.trim();
    if (!value || isBusy) return;
    let files: FileList | undefined;
    if (attachments.length > 0) {
      const dt = new DataTransfer();
      attachments.forEach((f) => dt.items.add(f));
      files = dt.files;
    }
    void sendMessage({ text: value, files });
    const item: HistoryItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: makeTitle(value),
      prompt: value,
      at: Date.now(),
    };
    setHistory((prev) => {
      const next = [item, ...prev].slice(0, 50);
      try {
        localStorage.setItem("nexus.history", JSON.stringify(next));
      } catch {
        // ignore quota
      }
      return next;
    });
    setInput("");
    setAttachments([]);
  };

  const openFilePicker = (accept: string, capture?: "user" | "environment") => {
    fileAcceptRef.current = accept;
    fileCaptureRef.current = capture;
    const el = fileInputRef.current;
    if (!el) return;
    el.accept = accept;
    if (capture) el.setAttribute("capture", capture);
    else el.removeAttribute("capture");
    el.value = "";
    el.click();
  };

  const handleToolClick = (tool: CreateTool) => {
    setMenuOpen(false);
    if (tool.action === "image") {
      setImageOpen(true);
      return;
    }
    if (tool.action === "links") {
      setLinksOpen(true);
      return;
    }
    if (tool.accept) {
      openFilePicker(tool.accept, tool.capture);
      return;
    }
    if (tool.prompt) {
      setInput((prev) => (prev ? prev : tool.prompt!));
      setTimeout(() => inputRef.current?.focus(), 0);
      return;
    }
    setNotice(`${tool.label} is coming soon.`);
    setTimeout(() => setNotice(null), 2400);
  };

  const onFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list) return;
    setAttachments((prev) => [...prev, ...Array.from(list)]);
  };

  const toggleMic = () => {
    const Ctor = getSpeechRecognition();
    if (!Ctor) {
      setNotice("Voice input isn't supported in this browser.");
      setTimeout(() => setNotice(null), 2400);
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    const rec = new Ctor();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = navigator.language || "en-US";
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rec.onresult = (event: any) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setInput((prev) => (prev ? prev + " " : "") + transcript.trim());
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    setListening(true);
    rec.start();
  };

  return (
    <div className="relative mx-auto flex h-[100dvh] w-full max-w-4xl flex-col px-4 py-6">
      {imageOpen && <ImageMode onClose={() => setImageOpen(false)} />}
      {linksOpen && <AILinksModal onClose={() => setLinksOpen(false)} />}
      {/* Header */}
      <header className="flex items-center justify-between pb-6">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl glass glow">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight">Nexus</h1>
            <p className="text-xs text-muted-foreground">Multimodal AI Hub</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setHistoryOpen((v) => !v)}
            className={`flex items-center gap-1.5 rounded-full glass px-3 py-1.5 text-xs transition ${
              historyOpen ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
            aria-label="Toggle history"
          >
            <History className="h-3.5 w-3.5" />
            History
            {history.length > 0 && (
              <span className="rounded-full bg-primary/20 px-1.5 text-[10px] text-primary">
                {history.length}
              </span>
            )}
          </button>
          <div className="hidden items-center gap-2 rounded-full glass px-3 py-1.5 text-xs text-muted-foreground sm:flex">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
            Online · Abel 3 Flash
          </div>
          <LogoutButton />
        </div>
      </header>

      {historyOpen && (
        <div className="mb-4 overflow-hidden rounded-2xl glass">
          <div className="flex items-center justify-between border-b border-border px-4 py-2">
            <span className="text-xs font-medium text-muted-foreground">
              Recent prompts
            </span>
            {history.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setHistory([]);
                  try {
                    localStorage.removeItem("nexus.history");
                  } catch {
                    // ignore
                  }
                }}
                className="text-[11px] text-muted-foreground hover:text-destructive"
              >
                Clear all
              </button>
            )}
          </div>
          {history.length === 0 ? (
            <p className="px-4 py-6 text-center text-xs text-muted-foreground">
              Nothing yet — your prompts will appear here with auto-generated titles.
            </p>
          ) : (
            <ul className="max-h-64 divide-y divide-border overflow-y-auto">
              {history.map((h) => (
                <li key={h.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setInput(h.prompt);
                      setHistoryOpen(false);
                      setTimeout(() => inputRef.current?.focus(), 0);
                    }}
                    className="flex w-full items-center justify-between gap-3 px-4 py-2 text-left text-sm transition hover:bg-secondary"
                  >
                    <span className="truncate text-foreground">{h.title}</span>
                    <span className="shrink-0 text-[10px] text-muted-foreground">
                      {new Date(h.at).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto pr-1">
        {messages.length === 0 ? (
          <EmptyState onPick={(t) => submit(t)} suggestions={suggestions} />
        ) : (
          <div className="space-y-6 pb-6">
            {messages.map((m) => (
              <MessageBubble key={m.id} message={m} />
            ))}
            {status === "submitted" && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                Thinking…
              </div>
            )}
            {error && (
              <div className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive-foreground">
                {error.message || "Something went wrong."}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Composer */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(input);
        }}
        className="glass relative mt-4 rounded-2xl p-2 shadow-[var(--shadow-elevated)]"
      >
        {/* Plus menu */}
        {menuOpen && (
          <div className="absolute bottom-full left-0 z-20 mb-2 w-72 overflow-hidden rounded-2xl glass shadow-[var(--shadow-elevated)]">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <span className="text-xs font-medium text-muted-foreground">Create</span>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                className="rounded-md p-1 text-muted-foreground hover:text-foreground"
                aria-label="Close menu"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            <ul className="p-1">
              {CREATE_TOOLS.map((t) => (
                <li key={t.id}>
                  <button
                    type="button"
                    onClick={() => handleToolClick(t)}
                    className="flex w-full items-start gap-3 rounded-xl px-3 py-2 text-left transition hover:bg-secondary"
                  >
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 text-primary">
                      <t.icon className="h-4 w-4" />
                    </span>
                    <span className="flex flex-col">
                      <span className="text-sm text-foreground">{t.label}</span>
                      <span className="text-[11px] text-muted-foreground">{t.description}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Attachments */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 px-2 pb-2 pt-1">
            {attachments.map((f, idx) => (
              <span
                key={`${f.name}-${idx}`}
                className="flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs text-foreground"
              >
                <FileText className="h-3 w-3 text-primary" />
                <span className="max-w-[160px] truncate">{f.name}</span>
                <button
                  type="button"
                  onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
                  className="text-muted-foreground hover:text-foreground"
                  aria-label={`Remove ${f.name}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        )}

        {notice && (
          <div className="mx-2 mb-2 rounded-lg bg-secondary px-3 py-1.5 text-[11px] text-muted-foreground">
            {notice}
          </div>
        )}

        <div className="flex items-end gap-1.5">
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl transition ${
              menuOpen ? "bg-primary/20 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
            aria-label="Open create menu"
          >
            <Plus className={`h-5 w-5 transition ${menuOpen ? "rotate-45" : ""}`} />
          </button>
          <button
            type="button"
            onClick={toggleMic}
            className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl transition ${
              listening
                ? "bg-destructive/20 text-destructive animate-pulse"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
            aria-label={listening ? "Stop voice input" : "Start voice input"}
          >
            {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </button>
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit(input);
              }
            }}
            rows={1}
            placeholder={listening ? "Listening…" : "Type your idea or speak…"}
            className="flex-1 resize-none bg-transparent px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
            style={{ maxHeight: 200 }}
          />
          <button
            type="submit"
            disabled={!input.trim() || isBusy}
            className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label="Send"
          >
            {isBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
          </button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={onFiles}
        />
      </form>
      <p className="mt-2 text-center text-[11px] text-muted-foreground">
        Speak, create, upload, research, design — all from one bar.
      </p>
    </div>
  );
}

function EmptyState({
  onPick,
  suggestions,
}: {
  onPick: (text: string) => void;
  suggestions: { icon: typeof Sparkles; label: string }[];
}) {
  return (
    <div className="flex flex-col items-center justify-center pt-12 text-center">
      <div className="mb-6 grid h-16 w-16 place-items-center rounded-2xl glass glow">
        <Sparkles className="h-7 w-7 text-primary" />
      </div>
      <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">
        Ask <span className="text-gradient">anything.</span>
      </h2>
      <p className="mt-3 max-w-md text-sm text-muted-foreground">
        One assistant. Text answers and image generation, woven together.
      </p>
      <div className="mt-8 grid w-full max-w-2xl grid-cols-1 gap-2 sm:grid-cols-2">
        {suggestions.map((s) => (
          <button
            key={s.label}
            type="button"
            onClick={() => onPick(s.label)}
            className="group flex items-center gap-3 rounded-xl glass px-4 py-3 text-left text-sm text-foreground transition hover:border-primary/50 hover:glow"
          >
            <s.icon className="h-4 w-4 text-primary transition group-hover:scale-110" />
            <span>{s.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

type MessagePart = {
  type: string;
  text?: string;
  output?: unknown;
  state?: string;
  mediaType?: string;
  url?: string;
  filename?: string;
};

function MessageBubble({ message }: { message: { id: string; role: string; parts: MessagePart[] } }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${
          isUser ? "bg-secondary" : "bg-gradient-to-br from-primary to-accent"
        }`}
      >
        {isUser ? (
          <User className="h-4 w-4 text-foreground" />
        ) : (
          <Bot className="h-4 w-4 text-primary-foreground" />
        )}
      </div>
      <div className={`max-w-[85%] space-y-2 ${isUser ? "items-end" : "items-start"}`}>
        {message.parts.map((part, i) => {
          if (part.type === "text") {
            return (
              <div
                key={i}
                className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                  isUser
                    ? "bg-gradient-to-br from-primary/20 to-accent/20 text-foreground"
                    : "glass text-foreground"
                }`}
              >
                <div className="prose prose-sm prose-invert max-w-none prose-p:my-1 prose-pre:bg-secondary prose-code:text-primary">
                  <ReactMarkdown>{part.text ?? ""}</ReactMarkdown>
                </div>
              </div>
            );
          }
          if (part.type === "tool-generate_image") {
            return <ImageToolPart key={i} part={part} />;
          }
          if (part.type === "file" && part.url) {
            const isImage = (part.mediaType ?? "").startsWith("image/");
            if (isImage) {
              return (
                <figure key={i} className="overflow-hidden rounded-2xl glass">
                  <img src={part.url} alt={part.filename ?? "Uploaded image"} className="h-auto max-h-80 w-full object-contain" />
                </figure>
              );
            }
            return (
              <a
                key={i}
                href={part.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 rounded-xl glass px-3 py-2 text-xs text-foreground hover:text-primary"
              >
                <FileText className="h-3.5 w-3.5 text-primary" />
                {part.filename ?? "Attachment"}
              </a>
            );
          }
          return null;
        })}
      </div>
    </div>
  );
}

function ImageToolPart({ part }: { part: MessagePart }) {
  const state = part.state;
  if (state === "input-streaming" || state === "input-available") {
    return (
      <div className="glass flex items-center gap-3 rounded-2xl px-4 py-3 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin text-primary" />
        Conjuring image…
      </div>
    );
  }
  const output = part.output as { imageUrl?: string; alt?: string; prompt?: string; error?: string } | undefined;
  if (output?.error) {
    return (
      <div className="rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive-foreground">
        Image failed: {output.error}
      </div>
    );
  }
  if (output?.imageUrl) {
    return (
      <figure className="overflow-hidden rounded-2xl glass glow">
        <img src={output.imageUrl} alt={output.alt ?? "Generated image"} className="h-auto w-full" />
        <figcaption className="flex items-center justify-between gap-3 border-t border-border px-4 py-2 text-xs text-muted-foreground">
          <span className="truncate">{output.prompt ?? "Generated image"}</span>
          <a
            href={output.imageUrl}
            download="nexus-image.png"
            target="_blank"
            rel="noreferrer"
            className="shrink-0 rounded-md bg-secondary px-2 py-1 text-[11px] text-foreground hover:text-primary"
          >
            Download
          </a>
        </figcaption>
      </figure>
    );
  }
  return null;
}